# DDoS Tester Legal
Gunakan ini hanya untuk menguji beban server milikmu sendiri.
