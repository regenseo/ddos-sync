
import argparse
import asyncio
from methods.get_flood import run_get_flood

parser = argparse.ArgumentParser()
parser.add_argument("--target", required=True)
parser.add_argument("--connections", type=int, default=100)
parser.add_argument("--duration", type=int, default=60)
args = parser.parse_args()

async def main():
    await run_get_flood(args.target, args.duration, args.connections)

if __name__ == "__main__":
    asyncio.run(main())
